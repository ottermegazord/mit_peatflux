while 1:

	file = open("test.txt", "a")
        file.write("test")
	file.close()
